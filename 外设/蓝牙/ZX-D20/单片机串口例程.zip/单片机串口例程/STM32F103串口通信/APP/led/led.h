#ifndef _led_H
#define _led_H

#include "system.h"

/*  LEDʱ�Ӷ˿ڡ����Ŷ��� */
#define LED_PORT 			GPIOE   
#define LED_PIN 			(GPIO_Pin_0|GPIO_Pin_12|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7)
#define LED_PORT_RCC		RCC_APB2Periph_GPIOE


#define led1 PEout(12)
#define led2 PEout(1)
#define led3 PEout(2)


void LED_Init(void);


#endif
