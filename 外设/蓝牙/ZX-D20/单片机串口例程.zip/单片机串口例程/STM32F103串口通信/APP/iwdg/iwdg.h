#ifndef _iwdg_H
#define _iwdg_H

#include "system.h"
void IWDG_Init(u8 pre,u16 rlr);
void IWDG_FeedDog(void);  //ι��

#endif

