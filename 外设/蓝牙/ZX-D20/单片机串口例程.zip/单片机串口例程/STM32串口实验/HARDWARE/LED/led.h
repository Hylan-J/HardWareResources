#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
				  
////////////////////////////////////////////////////////////////////////////////// 
#define LED0 PAout(4)// PB5
#define LED1 PAout(5)// PA5	

void LED_Init(void);//��ʼ��

		 				    
#endif
